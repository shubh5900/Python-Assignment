"""
You are given an array containing only the elements 0, 1, and 2. Your task is to sort 
the array in a single pass, with the end goal being that all 0s come before all 1s, and 
all 1s come before all 2s. Write a Python function that accomplishes this task with the 
following requirements:

"""

def sort(arr):
    zero=0
    one=0
    two=0
    
    for i in arr:
        if i ==0:
            zero+=1
        elif i==1:
            one+=1    
        else:
            two+=1
    sortArr=[]
    for i in range(zero):
        sortArr+=[0]
    for i in range(one):
        sortArr+=[1]
    for i in range(two):
        sortArr+=[2]
    return sortArr


arr=list(map(int,input().split()))
print(*sort(arr))            

"""
tase case :

input :0 1 2 0 2 0 1 1 2 2 1
output:0 0 0 1 1 1 1 2 2 2 2
 
input:0 1 2 2 1 2 1 2 0 0 0 0
output:0 0 0 0 0 1 1 1 2 2 2 2


"""