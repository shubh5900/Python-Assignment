"""
3.) Objective: You are given two dictionaries, dict1 and dict2. Your task is to merge these
dictionaries by adding their values for common keys. If a key is present in one dictionary but not
the other, include it in the merged dictionary with its original value.
Write a Python function that accomplishes this merging task with the following requirements:
"""

list1=list(map(str,input().split()))
dict1={}
for i in range(len(list1)//2):
    dict1[list1[2*i]]=int(list1[2*i+1])

list2=list(map(str,input().split()))  
dict2={}  
for i in range(len(list2)//2):
    dict2[list2[2*i]]=int(list2[2*i+1])

      

for i in dict1:
    if i in dict2:
        dict2[i]=dict1[i]+dict2[i]
    else:
        dict2[i]=dict1[i]  
print(dict2)          

"""
#testcase 1
input
a 2 b 5 c 3
b 1 c 7 d 4
output
a 2 b 6 c 10 d 4

#testcase 2
input
q 1 w 2 e 3 r 4 t 5
a 1 s 2 d 3 f 3 g 4 q 1
output
{'a': 1, 's': 2, 'd': 3, 'f': 3, 'g': 4, 'q': 2, 'w': 2, 'e': 3, 'r': 4, 't': 5}


#testcase 3
input
a 1 b 2 c 3 d 4
a 1 b 2 c 3 d 4

output
{'a': 2, 'b': 4, 'c': 6, 'd': 8}


"""



