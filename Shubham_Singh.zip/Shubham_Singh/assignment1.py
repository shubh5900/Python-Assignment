
# A customer is visiting a grocery store for fresh supplies. 
# There are N items in the
# store, each with a freshness value A and a cost B. 
# The customer wants to purchase items with a
# freshness value greater than or equal to X. Your task is to find 
#the total cost of the groceries the customer buys.


t=int(input())
for _ in range(t):
    N,X=list(map(int,input().split()))

    freshness=list(map(int,input().split()))
    costs =list(map(int,input().split()))
    Total_costs=0
    for i in range(N):
        if freshness[i]>X:
            Total_costs+=costs[i]



    print(Total_costs)


"""
#testcase 1

input:
1
5 7
9 6 8 7 10
12 8 10 15 9

output2
31

#testcase 2
input:
2           
3 4
3 4 5
10 23 45
4 6
1 2 3 4 
9 9 9 9

output:
45
0


testcase 3

input:
2
10 5
1 2 3 4 5 6 7 8 9 10
5 6 7 8 9 0 1 2 3 4
6 4
1 2 3 4 5 6
2 3 4 5 6 7

output:
10
13
"""
